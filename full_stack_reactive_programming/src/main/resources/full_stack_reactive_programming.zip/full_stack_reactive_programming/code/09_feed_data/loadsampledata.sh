mongoimport --db todo --collection tasks --drop --file ./sampledata.json
