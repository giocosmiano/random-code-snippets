1. On command prompt, run

runmongod.sh

2. On command prompt, run

loadsampledata.sh

3. On command prompt, compile code by running

gradlew 

4. On a command window, run

gradlew runServer
                 
5. On another command window, run

gradlew runClient