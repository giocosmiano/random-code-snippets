fun String.shout() = toUpperCase()

println("hello".shout())
