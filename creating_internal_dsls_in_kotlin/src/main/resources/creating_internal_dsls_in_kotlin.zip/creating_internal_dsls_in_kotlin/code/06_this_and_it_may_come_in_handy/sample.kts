val colors = listOf("Red", "Green", "Blue")

colors.forEach { color -> println(color) }

colors.forEach { println(it) }