val greet = "hello"

fun String.shout() = toUpperCase()                     

println(greet.shout())